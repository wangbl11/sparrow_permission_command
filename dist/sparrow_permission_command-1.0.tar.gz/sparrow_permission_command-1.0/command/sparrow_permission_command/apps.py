from django.apps import AppConfig


class SparrowPermissionCommandConfig(AppConfig):
    name = 'sparrow_permission_command'
